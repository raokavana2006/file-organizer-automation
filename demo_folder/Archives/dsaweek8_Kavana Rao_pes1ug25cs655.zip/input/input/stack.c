#include <stdio.h>
#include "stack.h"

void init_stack(stack_t *st)
{
    st->top_ = -1;
}

int is_empty(const stack_t *st)
{
    return st->top_ == -1;
}

int is_full(const stack_t *st)
{
    return st->top_ == MAXSIZE - 1;
}

int push(stack_t *st, int elem)
{
    if (is_full(st))
    {
        printf("stack full\n");
        return 0;
    }
    st->s[++(st->top_)] = elem;
    printf("push: index : %d\n", elem);
    return 1;
}

int pop(stack_t *st, int *pelem)
{
    if (is_empty(st))
    {
        printf("stack empty\n");
        return 0;
    }
    *pelem = st->s[(st->top_)--];
    printf("pop: index : %d\n", *pelem);
    return 1;
}