#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

int main(void)
{
    tree_t tree;
    init(&tree);

    int choice, key;

    while (1)
    {
        printf("enter option 1 : insert; 2 : delete key 3 : display 0 : exit : ");
        if (scanf("%d", &choice) != 1)
        {
            break;
        }

        switch (choice)
        {
            case 1:
                scanf("%d", &key);
                insert(&tree, key);
                break;

            case 2:
                scanf("%d", &key);
                delete_key(&tree, key);
                break;

            case 3:
                disp(&tree);
                break;

            case 0:
                exit(0);

            default:
                break;
        }
    }

    return 0;
}