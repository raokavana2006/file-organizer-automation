#ifndef TREE_H
#define TREE_H

#include "stack.h"

struct node
{
    int key_;
    int left_;
    int right_;
};
typedef struct node node_t;

struct tree 
{
    int root_;  // -1 on empty
    int count_; // # of elements
    node_t elem_[MAXSIZE];
    stack_t st_; // Memory manager stack
};
typedef struct tree tree_t;

void init(tree_t *ptr_tree);
void insert(tree_t *ptr_tree, int key);
void disp(tree_t *ptr_tree);
int delete_key(tree_t *ptr_tree, int key);

// Additional Exercises
int count_nodes(const tree_t *ptr_tree);
int count_leaves(const tree_t *ptr_tree);
int compare_trees(const tree_t *t1, const tree_t *t2);
void copy_tree(const tree_t *src, tree_t *dest);

#endif