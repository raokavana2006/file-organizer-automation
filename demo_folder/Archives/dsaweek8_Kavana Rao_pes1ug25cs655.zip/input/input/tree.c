#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

void init(tree_t *ptr_tree)
{
    ptr_tree->root_ = -1;
    ptr_tree->count_ = 0;
    
    init_stack(&(ptr_tree->st_));

    // Push indices from MAXSIZE - 1 down to 0 so index 0 is at the top of the stack
    for (int i = MAXSIZE - 1; i >= 0; --i)
    {
        push(&(ptr_tree->st_), i);
    }
}

static int insert_recursive(node_t elem[], int root, int temp)
{
    if (root == -1)
    {
        return temp;
    }
    if (elem[temp].key_ < elem[root].key_)
    {
        elem[root].left_ = insert_recursive(elem, elem[root].left_, temp);
    }
    else if (elem[temp].key_ > elem[root].key_)
    {
        elem[root].right_ = insert_recursive(elem, elem[root].right_, temp);
    }
    else
    {
        printf("Duplicate key %d not allowed.\n", elem[temp].key_);
    }
    return root;
}

void insert(tree_t *ptr_tree, int key)
{
    int temp;
    
    // Obtain location by popping from the stack
    if (pop(&(ptr_tree->st_), &temp) == 0)
    {
        return;
    }

    ptr_tree->elem_[temp].key_ = key;
    ptr_tree->elem_[temp].left_ = -1;
    ptr_tree->elem_[temp].right_ = -1;

    ptr_tree->root_ = insert_recursive(ptr_tree->elem_, ptr_tree->root_, temp);
    ptr_tree->count_++;
}

static void disp_recursive(const node_t elem[], int temp)
{
    if (temp != -1)
    {
        disp_recursive(elem, elem[temp].left_);
        printf("%d ", elem[temp].key_);
        disp_recursive(elem, elem[temp].right_);
    }
}

void disp(tree_t *ptr_tree)
{
    if (ptr_tree->root_ == -1)
    {
        printf("Tree is empty.\n");
        return;
    }
    disp_recursive(ptr_tree->elem_, ptr_tree->root_); 
    printf("\n");
}

static int inorder_successor(const node_t elem[], int root)
{
    int curr = elem[root].right_;
    while (curr != -1 && elem[curr].left_ != -1)
    {
        curr = elem[curr].left_;
    }
    return curr;
}

static int delete_key_recursive(tree_t *ptr_tree, int root, int key, int *found)
{
    node_t *elem = ptr_tree->elem_;

    if (root == -1)
    {
        return -1;
    }

    if (key < elem[root].key_)
    {
        elem[root].left_ = delete_key_recursive(ptr_tree, elem[root].left_, key, found);
    }
    else if (key > elem[root].key_)
    {
        elem[root].right_ = delete_key_recursive(ptr_tree, elem[root].right_, key, found);
    }
    else
    {
        *found = 1;

        // Leaf or only right child
        if (elem[root].left_ == -1)
        {
            int temp = elem[root].right_;
            push(&(ptr_tree->st_), root); // Push freed index back to stack
            return temp;
        }
        // Only left child
        else if (elem[root].right_ == -1)
        {
            int temp = elem[root].left_;
            push(&(ptr_tree->st_), root); // Push freed index back to stack
            return temp;
        }
        // Two subtrees
        else
        {
            int succ = inorder_successor(elem, root);
            elem[root].key_ = elem[succ].key_;
            elem[root].right_ = delete_key_recursive(ptr_tree, elem[root].right_, elem[succ].key_, found);
        }
    }
    return root;
}

int delete_key(tree_t *ptr_tree, int key)
{
    int found = 0;
    ptr_tree->root_ = delete_key_recursive(ptr_tree, ptr_tree->root_, key, &found);
    if (found)
    {
        ptr_tree->count_--;
        return 1;
    }
    return 0;
}

// Additional Exercises

static int count_nodes_recursive(const node_t elem[], int root)
{
    if (root == -1) return 0;
    return 1 + count_nodes_recursive(elem, elem[root].left_) + count_nodes_recursive(elem, elem[root].right_);
}

int count_nodes(const tree_t *ptr_tree)
{
    return count_nodes_recursive(ptr_tree->elem_, ptr_tree->root_);
}

static int count_leaves_recursive(const node_t elem[], int root)
{
    if (root == -1) return 0;
    if (elem[root].left_ == -1 && elem[root].right_ == -1) return 1;
    return count_leaves_recursive(elem, elem[root].left_) + count_leaves_recursive(elem, elem[root].right_);
}

int count_leaves(const tree_t *ptr_tree)
{
    return count_leaves_recursive(ptr_tree->elem_, ptr_tree->root_);
}

static int compare_recursive(const node_t e1[], int r1, const node_t e2[], int r2)
{
    if (r1 == -1 && r2 == -1) return 1;
    if (r1 == -1 || r2 == -1) return 0;

    return (e1[r1].key_ == e2[r2].key_) &&
           compare_recursive(e1, e1[r1].left_, e2, e2[r2].left_) &&
           compare_recursive(e1, e1[r1].right_, e2, e2[r2].right_);
}

int compare_trees(const tree_t *t1, const tree_t *t2)
{
    return compare_recursive(t1->elem_, t1->root_, t2->elem_, t2->root_);
}

static int copy_recursive(const node_t src_elem[], int src_root, tree_t *dest)
{
    if (src_root == -1) return -1;

    int new_idx;
    if (pop(&(dest->st_), &new_idx) == 0) return -1;

    dest->elem_[new_idx].key_ = src_elem[src_root].key_;
    dest->elem_[new_idx].left_ = copy_recursive(src_elem, src_elem[src_root].left_, dest);
    dest->elem_[new_idx].right_ = copy_recursive(src_elem, src_elem[src_root].right_, dest);

    return new_idx;
}

void copy_tree(const tree_t *src, tree_t *dest)
{
    init(dest);
    dest->root_ = copy_recursive(src->elem_, src->root_, dest);
    dest->count_ = src->count_;
}