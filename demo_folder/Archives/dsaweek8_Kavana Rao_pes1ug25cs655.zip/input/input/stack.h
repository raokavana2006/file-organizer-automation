#ifndef STACK_H
#define STACK_H

#define MAXSIZE 4

struct stack
{
    int s[MAXSIZE];
    int top_;
};
typedef struct stack stack_t;

void init_stack(stack_t *st);
int is_empty(const stack_t *st);
int is_full(const stack_t *st);
int push(stack_t *st, int elem);
int pop(stack_t *st, int *pelem);

#endif